//
// Created by kitatine on 2019/7/17.
//

#include "piece.h"

using namespace std;

Piece::Piece(Height h, Color c, Shape s, Top t):h(h),c(c),s(s),t(t),used(false) {
}

bool Piece::compareHeight(const Piece &p) const {
    return (this->h==p.h);
}

bool Piece::compareColor(const Piece &p) const {
    return (this->c==p.c);
}

bool Piece::compareShape(const Piece &p) const {
    return (this->s==p.s);
}

bool Piece::compareTop(const Piece &p) const {
    return(this->t==p.t);
}

bool Piece::isUsed() const {
    return this->used;
}

void Piece::setUsed(bool u) {
    this->used = u;
}

string Piece::toString() const {
    return string {ALLCODE[0][this->h],ALLCODE[1][this->c],ALLCODE[2][this->s],ALLCODE[3][this->t]};
}

