//
// Created by kitatine on 2019/7/17.
//

#include "pool.h"

using namespace std;

Piece& Pool::getUnusedPiece(int index){
    if (this->pieces[index].isUsed()){throw UsedPieceException(this->pieces[index]);}
    else return this->pieces[index];
}

Pool::Pool() {
    //constructors
    for (int i = 0; i < NP; i++){
        pieces[i] = Piece(Height(i/8%2),Color(i/4%2),Shape(i/2%2),Top(i%2));
    }
}

Piece& Pool::getUnusedPiece(Height h, Color c, Shape s, Top t) {
    return getUnusedPiece(h*8+c*4+s*2+t);
}

Piece& Pool::getUnusedPiece(const std::string &in) {
    return getUnusedPiece((in[0]==ALLCODE[0][1])*8+(in[1]==ALLCODE[1][1])*4+(in[2]==ALLCODE[2][1])*2
                          +(in[3]==ALLCODE[3][1]));
}

std::string Pool::toString() const {
    string line1,line2;
    int num=0;
    line1 += "Available:\n";
    for (int i = 0; i < NP; i++){
        if (!pieces[i].isUsed())
        {   line1 += pieces[i].toString().substr(0,2);
            line2+=pieces[i].toString().substr(2,2);
            num++;
        if(i!=NP-1){
            line1+=" ";
            line2+=" ";
        }
        }
    }
    if (num==0) return "\n";//undefined; require further specifying
    else return line1 + "\n" + line2 + "\n";
}