#include "quarto.h"

const char HCODE[] = {'S', 'T'};
const char CCODE[] = {'B', 'E'};
const char SCODE[] = {'C', 'Q'};
const char TCODE[] = {'H', 'O'};
const char *ALLCODE[] = {HCODE, CCODE, SCODE, TCODE};

