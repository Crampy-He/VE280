//
// Created by kitatine on 2019/7/17.
//

#include "square.h"

using namespace std;

Square::Square(Vaxis v, Haxis h):v(v),h(h),p(nullptr) {
}
// EFFECTS: create an empty square at position (v, h)

Vaxis Square::getV() const {
    return this->v;
}

void Square::setV(Vaxis v) {
    this->v=v;
}

Haxis Square::getH() const {
    return this->h;
}

void Square::setH(Haxis h) {
    this->h=h;
}

bool Square::isEmpty() const {
    return (this->p==nullptr);
}

const Piece& Square::getPiece() const {
    if(this->isEmpty()){throw SquareException(*this,"empty");}
    else return *(this->p);
}

void Square::setPiece(const Piece *p) {
    this->p=p;
}

bool Square::isOnFirstDiagonal() const {
//    return (int(this->v) == int(this->h));
    return (int(this->v)==int(this->h));
}

bool Square::isOnSecondDiagonal() const {
    return (int(this->v)+int(this->h)==3);
}

std::string Square::toString() const {
    string s={char('A'+int(this->v)),char('1'+int(this->h))};
    return s;
}


