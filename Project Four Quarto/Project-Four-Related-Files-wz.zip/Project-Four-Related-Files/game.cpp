//
// Created by kitatine on 2019/7/18.
//
#include "piece.h"
#include "pool.h"
#include "square.h"
#include "board.h"
#include "player.h"
#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc,char* argv[]){
    //Initialize the playing environment
    Board board;
    Pool pool;
    bool flag=false;
    unsigned int seed=0;
    //load the first "h" or "m"
    string temp=argv[1];
    //load the seed
    if(argv[3]){seed=(unsigned int)strtol(argv[3],nullptr,10);}
    //Construct the two kinds of players
    Player* p1=getHumanPlayer(&board,&pool);
    Player* p2=getMyopicPlayer(&board,&pool,seed);
    //The Actual Player Arrays
    Player* p[3];//The player array with two members p[0],p[1]
    for (int i=0;i<2;i++){
        p[i]= nullptr;
    }
    if(temp=="h") p[0]=p1;
    else if(temp=="m"){
        p[0]=p2;
    }
    temp=argv[2];
    if(temp=="h") p[1]=p1;
    else if(temp=="m"){
        p[1]=p2;
    }
    while(true) {
        cout << board.toString() << endl;
        cout << pool.toString() << endl;
        for (int i = 0; i < 16; i++) {
            int index = i % 2;
            cout << "Player " << index + 1 << "'s turn to select a piece:" << endl;
            Piece &tpiece = p[index]->selectPiece();
            cout << tpiece.toString() << " selected." << "\n" << endl;
            cout << "Player " << 2 - index << "'s turn to select a square:" << endl;
            Square &tsquare = p[1 - index]->selectSquare(tpiece);
            cout << tsquare.toString() << " selected." << "\n" << endl;
            board.place(tpiece, tsquare);
            cout << board.toString() << endl;
            cout << pool.toString() << endl;
            flag = board.isWinning(tpiece, tsquare);
            if (flag) {
                cout << "Player " << 2 - index << " has won!" << endl;
                return 0;
            }
        }
        cout << "It is a draw.\n" << endl;
        return 0;
//        //swap the player
//        p[2]=p[1];
//        p[1]=p[0];
//        p[0]=p[2];
    }
}

