//
// Created by kitatine on 2019/7/17.
//
#include "piece.h"
#include "pool.h"
#include "square.h"
#include "board.h"
#include "player.h"
#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;


int main(int argc, char *argv[]) {
    Piece p = Piece(Height(1));
    Piece h = Piece(Height(0));
    Pool po;
    Piece k = po.getUnusedPiece(Height(0),Color(0),Shape(0),Top(1));
    Piece &sbch = po.getUnusedPiece("SBCH");
    Piece &sbco = po.getUnusedPiece("SBCO");
    Piece &sbqh = po.getUnusedPiece("SBQH");
    Piece &seco = po.getUnusedPiece("SECO");

//    Piece &seqh = po.getUnusedPiece("SEQH");
//    Piece &sbqo = po.getUnusedPiece("SBQO");
//    Piece &seqo = po.getUnusedPiece("SEQO");
//    Piece &tech = po.getUnusedPiece("TECH");
//    Piece &teqo = po.getUnusedPiece("TEQO");
//    Piece &sbch = po.getUnusedPiece("SBCH");
//    Piece &sech = po.getUnusedPiece("SECH");
//    Piece &sbco = po.getUnusedPiece("SBCO");
//    Piece &tbco = po.getUnusedPiece("TBCO");
////    Piece &tbqh = po.getUnusedPiece("TBQH");
//    Piece &tbch = po.getUnusedPiece("TBCH");
//    Piece &teco = po.getUnusedPiece("TECO");
//    Piece &sbqh = po.getUnusedPiece("SBQH");
//    Piece &seco = po.getUnusedPiece("SECO");



//    Piece &tbqo = po.getUnusedPiece("TBQO");
//    Piece &sbqo = po.getUnusedPiece("SBQO");
//    Piece &seqo = po.getUnusedPiece("SEQO");
//    Piece &seqh = po.getUnusedPiece("SEQH");
//    Piece &sech = po.getUnusedPiece("SECH");
//    Piece &seco = po.getUnusedPiece("SECO");
//    Piece &tbqo = po.getUnusedPiece("TBQO");
//    Piece &sbco = po.getUnusedPiece("SBCO");
//    seqo.setUsed(true);
    Square sss(Vaxis(2),Haxis(2));
    Board bob;
//    bob.place(seqh,bob.getSquare(Vaxis(0),Haxis(2)));
//    bob.place(sbqo,bob.getSquare(Vaxis(0),Haxis(3)));
//    bob.place(seqo,bob.getSquare(Vaxis(1),Haxis(0)));
//    bob.place(tech,bob.getSquare(Vaxis(1),Haxis(1)));
//    bob.place(teqo,bob.getSquare(Vaxis(1),Haxis(2)));
//    bob.place(sbch,bob.getSquare(Vaxis(1),Haxis(3)));
//    bob.place(sech,bob.getSquare(Vaxis(2),Haxis(0)));
//    bob.place(sbco,bob.getSquare(Vaxis(2),Haxis(1)));
//    bob.place(tbco,bob.getSquare(Vaxis(2),Haxis(2)));
//    bob.place(tbch,bob.getSquare(Vaxis(3),Haxis(1)));
//    bob.place(teco,bob.getSquare(Vaxis(3),Haxis(2)));

    bob.place(sbch,bob.getSquare(Vaxis(0),Haxis(0)));
    bob.place(sbco,bob.getSquare(Vaxis(0),Haxis(1)));
    bob.place(sbqh,bob.getSquare(Vaxis(0),Haxis(2)));

    bob.isWinning(seco,bob.getSquare(Vaxis(0),Haxis(3)));

//    Player *p2=getMyopicPlayer(&bob,&po,(unsigned int)time(0));
//    p2->selectPiece();


//    bob.place(tbqo,bob.getSquare(Vaxis(3),Haxis(0)));
//    bob.place(seco,bob.getSquare(Vaxis(2),Haxis(1)));
//    bob.place(sbqo,bob.getSquare(Vaxis(1),Haxis(2)));

//    cout << bob.isWinning(seqo,bob.getSquare(Vaxis(0),Haxis(3))) << endl;

//    cout << bob.isWinning(sbco,bob.getSquare(Vaxis(3),Haxis(3))) << endl;
//    bob.place(sech,bob.getSquare(Vaxis(3),Haxis(3)));
//    cout << bob.isWinning(seco,bob.getSquare(Vaxis(2),Haxis(3)))<<endl;
//     Player *p2=getMyopicPlayer(&bob,&po,(unsigned int)time(0));
//    cout<< p2->selectPiece().toString()<<endl;
//    cout << p2->selectSquare(tbqo).toString()<<endl;
//    cout<<seco.toString()<<endl;
//    Player *p1=getHumanPlayer(&bob,&po);
//    p1->selectPiece();
//    p1->selectSquare(seqo);
//    cout << "\t1\t2\t3\t4"<<endl;
//    cout << bob.getSquare(Vaxis(0),Haxis(0)).toString()<<endl;
    cout << bob.toString() << endl;
    cout << sss.isOnFirstDiagonal() <<endl;
    cout << sss.toString() << endl;
    cout << k.toString() << endl;
    cout << po.toString() << endl;
//    cout << seqo.isUsed() << endl;
    cout<< p.compareHeight(h) << endl;
    cout << p.toString() << endl;
    cout << Height(0) << endl;
    return 0;
}


