//
// Created by kitatine on 2019/7/18.
//

#include"player.h"
#include"quarto.h"
#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

class HumanPlayer : public Player{
public:
    HumanPlayer(Board *board, Pool *pool):Player(board,pool){};//inheritate the constructor of the base class with parameters
    Piece & selectPiece() override;
    Square & selectSquare(const Piece &p) override;
};

class MyopicPlayer : public Player{
public:
    MyopicPlayer(Board *board, Pool *pool, unsigned int seed=0):Player(board,pool){};
    Piece & selectPiece() override;
    Square & selectSquare(const Piece &p) override;
};


static bool isIllegalPiece(const string& piecestr){
    bool flag=false;
    if(piecestr.length()!=4) return true;
    else
    {
        for (unsigned int i=0;i<N;i++){
            string s =&ALLCODE[i][0];
            if ((strncmp(piecestr.substr(i,1).c_str(),s.c_str(),1)!=0)
            &&(strncmp(piecestr.substr(i,1).c_str(),&ALLCODE[i][1],1)!=0)){
                flag=true;
                break;
            }
        }
        return flag;
    }
}

static bool isIllegalSquare(const string& squarestr){
    if(squarestr.length()!=2)return true;
    else{
    const string Alphabet[]{"A","B","C","D"};
    const string Number[]{"1","2","3","4"};
    bool flag1=true,flag2=true;
    for (unsigned int j=0;j<4;j++){
        if(squarestr.substr(0,1)==Alphabet[j].substr(0,1)) {flag1=false;break;}
        }
    for (unsigned int j=0;j<4;j++){
         if(squarestr.substr(1,1)==Number[j].substr(0,1)) {flag2=false;break;}
        }
    return flag1||flag2;
    }
}

Piece& HumanPlayer::selectPiece() {
    //  EFFECTS: return a reference to an unused prompt piece according to thhe standard input cin.
    //  throw InvalidInputException if the input string doesn't correspond to an unused piece.
    //  throw UsedPieceException if the piece is already occupied.
    bool flag = false;
    string piecestr;
    while (!flag) {
        cout << "Enter a piece:" << flush;
        cin >> piecestr;
        try {
            bool tf = isIllegalPiece(piecestr);
            if (tf) throw InvalidInputException(piecestr);
            pool->getUnusedPiece(piecestr);
            flag = !tf;
        }
        catch (InvalidInputException &ie) {
            //catch by reference
            cout << ie.what() << endl;
        }
        catch (UsedPieceException &ue) {
            cout << ue.what() << endl;
        }
    }
    return pool->getUnusedPiece(piecestr);
}

Square& HumanPlayer::selectSquare(const Piece &p) {
    bool flag = false;
    string squarestr;
    while(!flag){
        cout << "Enter a position:" << flush;
        cin >> squarestr;
        try{
            bool tf = isIllegalSquare(squarestr);
            if(tf){throw InvalidInputException(squarestr);}
            board->getEmptySquare(squarestr);//throw SquareException here
            flag=!tf;
        }
        catch(InvalidInputException &ie){
            cout << ie.what() << endl;
        }
        catch(SquareException &se){
            cout << se.what() << endl;
        }
    }
    return board->getEmptySquare(squarestr);
}

Piece& MyopicPlayer::selectPiece() {
    //pseudo-random process
    //First obtain the available pieces on pool
    Piece *Available[NP],*Good[NP];
    for(int i=0;i<NP;i++){
        Available[i]= nullptr;
        Good[i]= nullptr;
    }
    int ci=0;//current index
    int atotal;
    int gtotal;
    bool flag;
    for (int i=0;i<NP;i++){
    try{
        Piece* p=&(pool->getUnusedPiece(Height(i/8%2),Color(i/4%2),Shape(i/2%2),Top(i%2)));
        Available[ci]=p;
        ci++;
    }
    catch(UsedPieceException &ue){continue;}
    }
    atotal=ci;
    ci=0;
    flag=false;
    for (int n=0;n<atotal;n++){
        for (int i=0;i<N;i++){
            for (int j=0;j<N;j++){
                try{
                flag=(board->isWinning(*Available[n],board->getEmptySquare(Vaxis(i),Haxis(j))));
                }
                catch(SquareException &se){continue;}
                if(flag)break;
            }
            if(flag)break;
        }
        if(!flag){Good[ci]=Available[n];ci++;}
    }
    gtotal=ci;
    if(gtotal==0){
        return *Available[rand()%atotal];
    }
    else return *Good[rand()%gtotal];
}

Square& MyopicPlayer::selectSquare(const Piece &p) {
    Square* FreeSquare[NP];
    int stotal=0;
    for (int i=0;i<N;i++){
        for (int j=0;j<N;j++){
            try{
               Square& ts=board->getEmptySquare(Vaxis(i),Haxis(j));
               if(board->isWinning(p,ts))return ts;
               else {FreeSquare[stotal]=&ts;stotal+=1;continue;}
            }
            catch(SquareException &se){
                continue;
            }
        }
    }
    return *FreeSquare[rand()%stotal];
}

Player *getHumanPlayer(Board *b, Pool *p){
    static HumanPlayer hu(b,p);
    return &hu;
}

Player *getMyopicPlayer(Board *b, Pool *p,unsigned int seed){
    srand(seed);
    static MyopicPlayer mo(b,p);
    return &mo;
}


//static HumanPlayer hu(nullptr,nullptr);
//static MyopicPlayer mo(nullptr, nullptr);

//Player *getHumanPlayer(Board *b, Pool *p){
//    //static instance style
//    static HumanPlayer hu(b,p);
//    return &hu;
//    //new pointer style
////    return (Player *)new HumanPlayer(b,p);
//
//    //global instance style
////    HumanPlayer Hu = HumanPlayer(b,p);
////    hu=Hu;
//}