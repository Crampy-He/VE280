//
// Created by kitatine on 2019/7/17.
//

#include "board.h"
#include <cstring>

using namespace std;

static const char alphabet[]={'a','b','c','d'};

Board::Board() {
    for (int i = 0; i < N;i++){
        for (int j = 0; j < N; j++){
            grid[i][j]=Square(Vaxis(i),Haxis(j));
        }
    }
}

Square& Board::getSquare(Vaxis v, Haxis h) {
    return grid[int(v)][int(h)];
}

Square& Board::getEmptySquare(Vaxis v, Haxis h) {
    if(!grid[int(v)][int(h)].isEmpty()){throw SquareException(grid[int(v)][int(h)],"not empty");}
    else return grid[int(v)][int(h)];
}

Square& Board::getEmptySquare(const std::string &s) {
    char c[2];
    strcpy(c,s.c_str());
    Square sq = grid[int(c[0]-'A')][int(c[1]-'1')];
    if(!sq.isEmpty()){throw SquareException(sq,"not empty");}
    else return grid[int(c[0]-'A')][int(c[1]-'1')];
}

void Board::place(Piece &p, Square &sq) {
    p.setUsed(true);
    sq.setPiece(&p);
}

bool Board::isWinning(const Piece &p, const Square &sq) {
    bool horizontalwin=false,verticalwin=false,diagonalwin1=false,diagonalwin=false;
    bool flag=false;
    int flagh=0,flagc=0,flags=0,flagt=0;
    int v = sq.getV();
    int h = sq.getH();

    //horizontal check
    for (int j=0;j<N;j++){
        if(j==h) continue;//skip itself
        else{
            if (this->getSquare(Vaxis(v),Haxis(j)).isEmpty()) break;
            else {
                flagh+=(p.compareHeight(this->getSquare(Vaxis(v),Haxis(j)).getPiece()));
                flagc+=(p.compareColor(this->getSquare(Vaxis(v),Haxis(j)).getPiece()));
                flags+=(p.compareShape(this->getSquare(Vaxis(v),Haxis(j)).getPiece()));
                flagt+=(p.compareTop(this->getSquare(Vaxis(v),Haxis(j)).getPiece()));
            }
        }
    }
    if (flagh==3||flagc==3||flagt==3||flags==3)flag=true;
    horizontalwin=flag;

    //vertical check
    flag=false;
    flagh=0;flagc=0;flags=0;flagt=0;
    for (int i=0;i<N;i++){
        if(i==v) continue;//skip itself
        else{
            if (this->getSquare(Vaxis(i),Haxis(h)).isEmpty()) break;
            else
            {
                flagh+=(p.compareHeight(this->getSquare(Vaxis(i),Haxis(h)).getPiece()));
                flagc+=(p.compareColor(this->getSquare(Vaxis(i),Haxis(h)).getPiece()));
                flags+=(p.compareShape(this->getSquare(Vaxis(i),Haxis(h)).getPiece()));
                flagt+=(p.compareTop(this->getSquare(Vaxis(i),Haxis(h)).getPiece()));
            }
        }
    }
    if (flagh==3||flagc==3||flagt==3||flags==3)flag=true;
    verticalwin=flag;

    //diagonal check
    flag=false;
    flagh=0;flagc=0;flags=0;flagt=0;
    if(sq.isOnFirstDiagonal()){
        for(int i=0;i<N;i++){
            if(i==h) continue;//skip itself
            else{
                if (this->getSquare(Vaxis(i),Haxis(i)).isEmpty()) break;
                else
                {
                    flagh+=(p.compareHeight(this->getSquare(Vaxis(i),Haxis(i)).getPiece()));
                    flagc+=(p.compareColor(this->getSquare(Vaxis(i),Haxis(i)).getPiece()));
                    flags+=(p.compareShape(this->getSquare(Vaxis(i),Haxis(i)).getPiece()));
                    flagt+=(p.compareTop(this->getSquare(Vaxis(i),Haxis(i)).getPiece()));
                }
            }
        }
     if (flagh==3||flagc==3||flagt==3||flags==3)flag=true;
     diagonalwin1=flag;}

    flag=false;
    flagh=0;flagc=0;flags=0;flagt=0;
    if(sq.isOnSecondDiagonal()){
        for(int i=0;i<N;i++){
            if(i==v) continue;//skip itself
            else{
                if (this->getSquare(Vaxis(i),Haxis(N-1-i)).isEmpty()) break;
                else
                {
                    flagh+=(p.compareHeight(this->getSquare(Vaxis(i),Haxis(N-1-i)).getPiece()));
                    flagc+=(p.compareColor(this->getSquare(Vaxis(i),Haxis(N-1-i)).getPiece()));
                    flags+=(p.compareShape(this->getSquare(Vaxis(i),Haxis(N-1-i)).getPiece()));
                    flagt+=(p.compareTop(this->getSquare(Vaxis(i),Haxis(N-1-i)).getPiece()));
                }
                }
            }
     if (flagh==3||flagc==3||flagt==3||flags==3)flag=true;
     diagonalwin=flag;}

    return (horizontalwin||verticalwin||diagonalwin1||diagonalwin);
}


std::string Board::toString() const {
    string ss="    1    2    3    4\n";
    string ssquare[N];
    string fsquare;
    for(int i=0;i<N;i++){
        ssquare[i]+="  +----+----+----+----+\n";
        ssquare[i]+=alphabet[i];
        ssquare[i]+=" ";
        for(int j=0;j<2*N;j++){
            if(j==N){
                ssquare[i]+="  ";
            }
            ssquare[i]+="|";
            if(!grid[i][j%N].isEmpty()){
                ssquare[i]+=" ";
                ssquare[i]+=grid[i][j%N].getPiece().toString().substr((unsigned int)j/N+(unsigned int)j/N,2);
                ssquare[i]+=" ";
            }
            else ssquare[i]+="    ";
            if((j==N-1)||(j==2*N-1))ssquare[i]+="|\n";
        }
        fsquare+=ssquare[i];
    }
    return ss+fsquare+"  +----+----+----+----+\n";
}

